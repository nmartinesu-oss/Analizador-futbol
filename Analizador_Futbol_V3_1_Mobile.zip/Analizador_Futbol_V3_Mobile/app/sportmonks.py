import httpx
from .config import TOKEN, BASE

class SMError(Exception):
    def __init__(self, message, status_code=None, detail=None):
        super().__init__(message)
        self.status_code = status_code
        self.detail = detail

class SM:
    def __init__(self):
        if not TOKEN:
            raise SMError("Falta SPORTMONKS_API_TOKEN en las variables del servidor.")
        # Sportmonks documenta autenticación mediante Authorization: Bearer <token>.
        self.h={"Accept":"application/json","Authorization":f"Bearer {TOKEN}"}

    async def get(self,path,params=None):
        url=f"{BASE.rstrip('/')}/{path.lstrip('/')}"
        async with httpx.AsyncClient(timeout=35) as c:
            r=await c.get(url,params=params or {},headers=self.h)
        try:
            payload=r.json()
        except Exception:
            payload=r.text
        if r.status_code>=400:
            raise SMError(f"Sportmonks HTTP {r.status_code}",r.status_code,payload)
        return payload.get("data",payload) if isinstance(payload,dict) else payload

    async def fixtures_date(self,d):
        return await self.get(f"fixtures/date/{d}",
            {"include":"participants;scores;state;league;season"})

    async def fixtures_between(self,a,b):
        return await self.get(f"fixtures/between/{a}/{b}",
            {"include":"participants;scores;state;league;season"})

    async def fixture(self,i):
        inc=("participants;scores;events;lineups.player;statistics.type;"
             "xGFixture.type;odds;referees;state;league;season;sidelined")
        return await self.get(f"fixtures/{i}",{"include":inc})

    async def recent(self,team,a,b):
        return await self.get(f"fixtures/between/{a}/{b}/{team}",
            {"include":"participants;scores;state;league;statistics.type;xGFixture.type"})

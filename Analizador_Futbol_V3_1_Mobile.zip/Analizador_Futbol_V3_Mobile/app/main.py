from fastapi import FastAPI,HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from datetime import date,timedelta
import asyncio, unicodedata
from .sportmonks import SM,SMError
from .parsers import parts,summary,odds
from .model import model,markets,confidence

app=FastAPI(title="Analizador de Fútbol V3.1 Mobile")
app.mount("/static",StaticFiles(directory="static"),name="static")

@app.get("/")
async def home():return FileResponse("static/index.html")

def norm(x):
    x=unicodedata.normalize("NFKD",x or "")
    x="".join(c for c in x if not unicodedata.combining(c))
    return " ".join("".join(c.lower() for c in x if c.isalnum() or c.isspace()).split())

def participant_location(p):
    meta=p.get("meta") or {}
    loc=meta.get("location") or p.get("location")
    if isinstance(loc,str): return loc.lower()
    return ""

def ordered_parts(ps):
    ps=list(ps or [])
    home=next((p for p in ps if participant_location(p)=="home"),None)
    away=next((p for p in ps if participant_location(p)=="away"),None)
    if home and away:return [home,away]
    return ps

def names_match(requested,actual):
    r,a=norm(requested),norm(actual)
    if r==a:return True
    # Tolerate common prefixes/suffixes such as Club, CF, FC and accents.
    stop={"club","cf","fc","futbol","futbolclub","fcf"}
    rr=" ".join(x for x in r.split() if x not in stop)
    aa=" ".join(x for x in a.split() if x not in stop)
    return rr==aa or (len(rr)>=5 and (rr in aa or aa in rr))

def find_match(fixtures,home,away):
    exact_order=None; reverse_order=None; fallback=[]
    for f in fixtures or []:
        ps=ordered_parts(parts(f))
        if len(ps)<2:continue
        hn,an=ps[0].get("name") or "",ps[1].get("name") or ""
        if names_match(home,hn) and names_match(away,an):exact_order=(f,False);break
        if names_match(home,an) and names_match(away,hn):reverse_order=(f,True)
        if names_match(home,hn) or names_match(home,an):fallback.append(f)
    return exact_order or reverse_order or ((fallback[0],False) if len(fallback)==1 else None)

async def discover(sm,match_date,home,away):
    # Search the requested date plus adjacent UTC dates. This handles timezone
    # differences between the user's local date and Sportmonks starting_at.
    candidates=[]; searched=[]
    for delta in (-1,0,1):
        d=match_date+timedelta(days=delta); searched.append(d.isoformat())
        try:
            fs=await sm.fixtures_date(d.isoformat())
            candidates.extend(fs or [])
        except SMError as e:
            # Keep going; the between endpoint is a useful fallback.
            if e.status_code not in (400,404): raise
    found=find_match(candidates,home,away)
    if found:return found,searched
    # Fallback to between endpoint across the 3-day window.
    fs=await sm.fixtures_between((match_date-timedelta(days=1)).isoformat(),
                                 (match_date+timedelta(days=2)).isoformat())
    found=find_match(fs,home,away)
    return found,searched

@app.get("/api/analyze")
async def analyze(home:str,away:str,match_date:date):
    try:
        sm=SM()
        found,searched=await discover(sm,match_date,home,away)
        if not found:
            raise HTTPException(404,detail={
                "message":"No encontré el partido en Sportmonks.",
                "requested":{"home":home,"away":away,"date":match_date.isoformat()},
                "searched_dates":searched,
                "hint":"La V3.1 buscó la fecha solicitada y un día antes/después, además de un fallback por rango."
            })
        base,reversed_request=found
        f=await sm.fixture(base["id"])
        p=ordered_parts(parts(f))
        if len(p)<2:raise HTTPException(502,"Sportmonks no devolvió los dos equipos del fixture.")
        hid,aid=p[0]["id"],p[1]["id"]
        actual_home,actual_away=p[0].get("name"),p[1].get("name")
        a0=(match_date-timedelta(days=180)).isoformat();b0=match_date.isoformat()
        hf,af=await asyncio.gather(sm.recent(hid,a0,b0),sm.recent(aid,a0,b0))
        hs,as_=summary(hf,hid),summary(af,aid)
        od=odds(f);m=model(hs,as_)
        flags={"lineups":bool(f.get("lineups")),"referee":bool(f.get("referees")),
               "sidelined":bool(f.get("sidelined")),"statistics":bool(f.get("statistics")),
               "xgfixture":bool(f.get("xgfixture") or f.get("expected")),"odds":bool(f.get("odds"))}
        cs,rs=confidence(hs,as_,od,flags)
        return {"fixture":{"id":f.get("id"),"name":f.get("name"),
                           "starting_at":f.get("starting_at"),
                           "league":(f.get("league") or {}).get("name"),
                           "season":(f.get("season") or {}).get("name")},
                "teams":{"home":actual_home,"away":actual_away},
                "request":{"home":home,"away":away,"date":match_date.isoformat(),
                           "searched_dates":searched,"reversed_order":reversed_request},
                "recent":{"home":hs,"away":as_},"odds":od,"model":m,
                "markets":markets(m,od),"confidence":{"score":cs,"reasons":rs},
                "flags":flags,"source":"Sportmonks API v3"}
    except HTTPException:raise
    except SMError as e:
        detail={"message":str(e),"status_code":e.status_code,"detail":e.detail}
        raise HTTPException(502,detail=detail)
    except Exception as e:raise HTTPException(500,str(e))

# V3.1

Cambios principales:
- Autenticación Sportmonks con `Authorization: Bearer <token>`.
- Búsqueda de fixtures por fecha exacta y +/- 1 día para tolerar diferencias UTC.
- Fallback adicional por endpoint `fixtures/between`.
- Normalización de acentos y nombres (América/America, FC/CF, etc.).
- El orden introducido por el usuario ya no tiene que coincidir con el orden local/visitante de Sportmonks.
- El fixture se ordena por `meta.location` cuando Sportmonks lo proporciona.
- Respuesta de diagnóstico: fixture ID, fecha API, fechas consultadas, orden invertido y presencia de estadísticas/xG/cuotas/alineaciones/árbitro/bajas.
- Errores de Sportmonks muestran código HTTP y detalle técnico al backend.

from fastapi import FastAPI,HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from datetime import date,timedelta
import asyncio
from .sportmonks import SM,SMError
from .parsers import parts,summary,odds
from .model import model,markets,confidence

app=FastAPI(title="Analizador de Fútbol V3 Mobile")
app.mount("/static",StaticFiles(directory="static"),name="static")

@app.get("/")
async def home():return FileResponse("static/index.html")

def norm(x):return "".join(c.lower() for c in x if c.isalnum() or c.isspace()).strip()

@app.get("/api/analyze")
async def analyze(home:str,away:str,match_date:date):
    try:
        sm=SM()
        fs=await sm.fixtures_between(match_date.isoformat(),(match_date+timedelta(days=1)).isoformat())
        h,a=norm(home),norm(away)
        base=None
        for f in fs:
            p=parts(f)
            names=[norm(x.get("name") or "") for x in p]
            if len(names)>=2 and names[0]==h and names[1]==a:
                base=f;break
        if not base:raise HTTPException(404,"No encontré el partido con esos nombres y fecha.")
        f=await sm.fixture(base["id"]);p=parts(f)
        if len(p)<2:raise HTTPException(502,"Sportmonks no devolvió los equipos.")
        hid,aid=p[0]["id"],p[1]["id"]
        a0=(match_date-timedelta(days=120)).isoformat();b0=match_date.isoformat()
        hf,af=await asyncio.gather(sm.recent(hid,a0,b0),sm.recent(aid,a0,b0))
        hs,as_=summary(hf,hid),summary(af,aid)
        od=odds(f);m=model(hs,as_)
        flags={"lineups":bool(f.get("lineups")),"referee":bool(f.get("referees")),
               "sidelined":bool(f.get("sidelined"))}
        cs,rs=confidence(hs,as_,od,flags)
        return {"fixture":{"id":f.get("id"),"name":f.get("name"),
                           "starting_at":f.get("starting_at"),
                           "league":(f.get("league") or {}).get("name")},
                "teams":{"home":p[0].get("name"),"away":p[1].get("name")},
                "recent":{"home":hs,"away":as_},"odds":od,"model":m,
                "markets":markets(m,od),"confidence":{"score":cs,"reasons":rs},
                "flags":flags}
    except HTTPException:raise
    except SMError as e:raise HTTPException(502,str(e))
    except Exception as e:raise HTTPException(500,str(e))

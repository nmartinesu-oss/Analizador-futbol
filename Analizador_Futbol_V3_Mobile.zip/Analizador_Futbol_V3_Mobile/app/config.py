import os
from dotenv import load_dotenv
load_dotenv()
TOKEN=os.getenv("SPORTMONKS_API_TOKEN","").strip()
BASE=os.getenv("SPORTMONKS_BASE_URL","https://api.sportmonks.com/v3/football").rstrip("/")

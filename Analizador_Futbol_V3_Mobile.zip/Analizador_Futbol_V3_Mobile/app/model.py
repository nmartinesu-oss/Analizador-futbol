import math
from statistics import mean

def pmf(k,l):
    if l<=0:return 1.0 if k==0 else 0.0
    return math.exp(-l)*l**k/math.factorial(k)

def clamp(x,a,b): return max(a,min(b,x))

def model(h,a):
    # Mezcla conservadora de ataque propio y defensa rival.
    hx=h.get("xg_for") or h.get("gf") or 1.2
    ha=h.get("ga") or 1.2
    ax=a.get("xg_for") or a.get("gf") or 1.2
    aa=a.get("ga") or 1.2
    lh=0.58*((hx+aa)/2)+0.42*(h.get("recent_gf") or h.get("gf") or 1.2)
    la=0.58*((ax+ha)/2)+0.42*(a.get("recent_gf") or a.get("gf") or 1.2)
    lh=clamp(lh*1.06,.20,4.2); la=clamp(la,.15,4.0)
    mat=[]; tot=0
    for i in range(11):
        row=[]
        for j in range(11):
            p=pmf(i,lh)*pmf(j,la); row.append(p); tot+=p
        mat.append(row)
    H=D=A=B=O=0
    scores=[]
    for i,row in enumerate(mat):
        for j,p in enumerate(row):
            p/=tot
            if i>j:H+=p
            elif i==j:D+=p
            else:A+=p
            if i>0 and j>0:B+=p
            if i+j>=3:O+=p
            scores.append((p,i,j))
    scores.sort(reverse=True)
    return {
      "home":H,"draw":D,"away":A,"btts":B,"over25":O,"under25":1-O,
      "xg_home":lh,"xg_away":la,"xg_total":lh+la,
      "scores":[{"score":f"{i}-{j}","p":p} for p,i,j in scores[:8]]
    }

def edge(p,o):
    if not p or not o or o<=1:return None
    return {"prob":p,"implied":1/o,"edge":p-1/o,"ev":p*o-1,"fair":1/p}

def markets(m,odds):
    mp={"home":"home","draw":"draw","away":"away","over25":"over25","btts":"btts"}
    return {k:edge(m[v],odds[k]) for k,v in mp.items() if k in odds}

def confidence(h,a,odds,flags):
    s=0; r=[]
    if h.get("sample",0)>=5 and a.get("sample",0)>=5:s+=25
    else:r.append("muestra < 5 partidos")
    if h.get("xg_sample",0)>=3 and a.get("xg_sample",0)>=3:s+=25
    else:r.append("xG parcial/no disponible")
    if len(odds)>=3:s+=20
    else:r.append("pocas cuotas")
    if flags["lineups"]:s+=15
    else:r.append("alineaciones no confirmadas")
    if flags["referee"]:s+=10
    else:r.append("árbitro no disponible")
    if flags["sidelined"]:s+=5
    else:r.append("bajas no disponibles")
    return min(s,100),r

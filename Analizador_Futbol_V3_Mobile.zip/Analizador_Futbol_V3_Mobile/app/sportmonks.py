import httpx
from .config import TOKEN, BASE

class SMError(Exception): pass

class SM:
    def __init__(self):
        if not TOKEN:
            raise SMError("Falta SPORTMONKS_API_TOKEN en .env o en las variables del servidor.")
        self.h={"Accept":"application/json","Authorization":TOKEN}

    async def get(self,path,params=None):
        async with httpx.AsyncClient(timeout=35) as c:
            r=await c.get(f"{BASE}/{path.lstrip('/')}",params=params or {},headers=self.h)
        if r.status_code>=400:
            try: detail=r.json()
            except: detail=r.text
            raise SMError(f"Sportmonks HTTP {r.status_code}: {detail}")
        x=r.json()
        return x.get("data",x)

    async def fixtures_between(self,a,b):
        return await self.get(f"fixtures/between/{a}/{b}",
            {"include":"participants;scores;state;league;season"})

    async def fixture(self,i):
        inc=("participants;scores;events;lineups.player;statistics.type;"
             "xgfixture.type;odds;referees;state;league;season;sidelined")
        return await self.get(f"fixtures/{i}",{"include":inc})

    async def recent(self,team,a,b):
        return await self.get(f"fixtures/between/{a}/{b}/{team}",
            {"include":"participants;scores;state;league;statistics.type;xgfixture.type"})

from statistics import mean

def arr(x):
    if isinstance(x,list):return x
    if isinstance(x,dict) and isinstance(x.get("data"),list):return x["data"]
    return [x] if isinstance(x,dict) else []

def parts(f):
    return arr(f.get("participants"))

def score(f,tid):
    for s in arr(f.get("scores")):
        if s.get("participant_id")==tid:
            z=s.get("score") or {}
            if isinstance(z,dict) and isinstance(z.get("goals"),(int,float)):return z["goals"]
    return None

def val(s):
    d=s.get("data")
    if isinstance(d,(int,float)):return d
    if isinstance(d,dict):
        for k in ("value","total","count"):
            if isinstance(d.get(k),(int,float)):return d[k]
    return None

def stats(f,tid):
    out={}
    aliases={"shots on target":"sot","shots total":"shots","corners":"corners",
             "yellow cards":"cards","yellowcards":"cards","offsides":"offsides",
             "ball possession":"possession"}
    for s in arr(f.get("statistics")):
        if s.get("participant_id") not in (None,tid):continue
        t=s.get("type") or {}
        n=(t.get("developer_name") or t.get("name") or s.get("name") or "").lower()
        v=val(s)
        if v is None:continue
        for a,k in aliases.items():
            if a in n:out[k]=v
    return out

def xg(f,tid):
    vals=[]
    for x in arr(f.get("xgfixture")):
        if x.get("participant_id")==tid:
            d=x.get("data") or x.get("xg") or x.get("value")
            if isinstance(d,dict):d=d.get("value")
            if isinstance(d,(int,float)):vals.append(d)
    return mean(vals) if vals else None

def summary(fs,tid):
    games=[]
    for f in fs:
        ps=parts(f); ids=[p.get("id") for p in ps]
        if tid not in ids:continue
        opp=next((i for i in ids if i!=tid),None)
        gf,ga=score(f,tid),score(f,opp)
        if gf is None or ga is None:continue
        st=stats(f,tid); xv=xg(f,tid)
        games.append({"gf":gf,"ga":ga,"xg":xv,**st})
    if not games:return {"sample":0,"gf":1.2,"ga":1.2,"recent_gf":1.2,"xg_for":None,
                         "xg_sample":0,"corners":None,"cards":None,"offsides":None,
                         "shots":None,"sot":None}
    def avg(k):
        q=[g[k] for g in games if isinstance(g.get(k),(int,float))]
        return mean(q) if q else None
    return {"sample":len(games),"gf":avg("gf") or 1.2,"ga":avg("ga") or 1.2,
            "recent_gf":avg("gf") or 1.2,"xg_for":avg("xg"),
            "xg_sample":sum(g.get("xg") is not None for g in games),
            "corners":avg("corners"),"cards":avg("cards"),"offsides":avg("offsides"),
            "shots":avg("shots"),"sot":avg("sot")}

def odds(f):
    out={}
    for o in arr(f.get("odds")):
        m=o.get("market") or {}
        n=(m.get("name") or m.get("developer_name") or o.get("name") or "").lower()
        lab=(o.get("label") or o.get("name") or "").lower()
        raw=o.get("value") or o.get("odds")
        try:v=float(raw)
        except:continue
        if "match winner" in n or "1x2" in n:
            if lab in ("1","home"):out["home"]=v
            elif lab in ("x","draw"):out["draw"]=v
            elif lab in ("2","away"):out["away"]=v
        elif "over/under" in n or "total goals" in n:
            if "over 2.5" in lab:out["over25"]=v
        elif "both teams" in n or "btts" in n:
            if lab in ("yes","si","sí"):out["btts"]=v
    return out

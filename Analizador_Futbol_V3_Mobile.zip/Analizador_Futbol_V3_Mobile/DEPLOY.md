# Despliegue rápido

## Opción A: servidor con Docker
1. Crea un servicio web con Docker.
2. Sube este proyecto.
3. Define `SPORTMONKS_API_TOKEN` como variable secreta del servicio.
4. El puerto usado es `$PORT` (por defecto 8000).
5. Abre la URL HTTPS desde Android.
6. En Chrome/Edge usa "Añadir a pantalla de inicio" o el botón de instalación de la app.

## Opción B: Python local
`pip install -r requirements.txt`
`uvicorn app.main:app --host 0.0.0.0 --port 8000`

Para acceder desde otro dispositivo de la misma red, usa la IP local del PC:
`http://IP_DEL_PC:8000`

Para acceso desde Internet, usa un servidor HTTPS. No expongas el servidor de desarrollo directamente sin protección.

## Seguridad
El token debe vivir únicamente como variable de entorno del backend. Nunca lo pongas en `static/` ni en JavaScript.
